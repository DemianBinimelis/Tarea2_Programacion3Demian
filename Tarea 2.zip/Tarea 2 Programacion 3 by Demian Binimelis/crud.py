from sqlalchemy.orm import Session
from vuelo_ORM import Vuelo
from lista_vuelos import lista_vuelos
from fastapi import HTTPException

undo_stack = []
redo_stack = []

def inicializar_lista(db: Session):
    lista_vuelos.cabeza = None
    lista_vuelos.cola = None
    lista_vuelos._size = 0

    vuelos_db = db.query(Vuelo).all()
    for vuelo in vuelos_db:
        lista_vuelos.insertar_al_final(vuelo)

def crear_vuelo(db: Session, datos: dict, es_emergencia: bool = False):
    try:
        vuelo = Vuelo(**datos, es_emergencia=es_emergencia)
        db.add(vuelo)
        db.commit()
        db.refresh(vuelo)

        if es_emergencia:
            lista_vuelos.insertar_al_frente(vuelo)
        else:
            lista_vuelos.insertar_al_final(vuelo)

        undo_stack.append(("crear", vuelo))
        return vuelo
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al crear vuelo: {str(e)}")

def obtener_vuelos():
    vuelos = []
    actual = lista_vuelos.cabeza
    while actual:
        vuelo_data = {
            "codigo": actual.datos_vuelo.codigo,
            "destino": actual.datos_vuelo.destino,
            "es_emergencia": actual.datos_vuelo.es_emergencia,
            "prioridad": "ALTA" if actual.datos_vuelo.es_emergencia else "normal"
        }
        vuelos.append(vuelo_data)
        actual = actual.siguiente
    return vuelos

def obtener_vuelo_en_posicion(posicion: int):
    actual = lista_vuelos.cabeza
    for _ in range(posicion):
        if actual is None:
            return None
        actual = actual.siguiente
    return actual.datos_vuelo if actual else None

def eliminar_vuelo(db: Session, posicion: int):
    vuelo = lista_vuelos.extraer_de_posicion(posicion)
    if vuelo:
        db.delete(vuelo)
        db.commit()
        undo_stack.append(("eliminar", vuelo, posicion))
    return vuelo

def insertar_en_posicion(db: Session, datos: dict, posicion: int):
    try:
        vuelo = Vuelo(**datos)
        db.add(vuelo)
        db.commit()
        db.refresh(vuelo)
        lista_vuelos.insertar_en_posicion(vuelo, posicion)
        undo_stack.append(("insertar", vuelo, posicion))
        return vuelo
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al insertar vuelo: {str(e)}")

def undo(db: Session):
    if not undo_stack:
        return None
    accion = undo_stack.pop()
    redo_stack.append(accion)

    tipo = accion[0]

    if tipo == "crear":
        vuelo = accion[1]
        actual = lista_vuelos.cabeza
        pos = 0
        while actual:
            if actual.datos_vuelo.id == vuelo.id:
                lista_vuelos.extraer_de_posicion(pos)
                break
            actual = actual.siguiente
            pos += 1
        db.delete(vuelo)
        db.commit()
        return {"acción": "deshecho", "tipo": "crear", "vuelo": vuelo.codigo}

    elif tipo == "eliminar":
        vuelo, pos = accion[1], accion[2]
        db.add(vuelo)
        db.commit()
        lista_vuelos.insertar_en_posicion(vuelo, pos)
        return {"acción": "deshecho", "tipo": "eliminar", "vuelo": vuelo.codigo}

    elif tipo == "insertar":
        vuelo, pos = accion[1], accion[2]
        lista_vuelos.extraer_de_posicion(pos)
        db.delete(vuelo)
        db.commit()
        return {"acción": "deshecho", "tipo": "insertar", "vuelo": vuelo.codigo}

def redo(db: Session):
    if not redo_stack:
        return None
    accion = redo_stack.pop()
    undo_stack.append(accion)

    tipo = accion[0]

    if tipo == "crear":
        vuelo = accion[1]
        db.add(vuelo)
        db.commit()
        lista_vuelos.insertar_al_final(vuelo)
        return {"acción": "rehecho", "tipo": "crear", "vuelo": vuelo.codigo}

    elif tipo == "eliminar":
        vuelo, _ = accion[1], accion[2]
        actual = lista_vuelos.cabeza
        pos_actual = 0
        while actual:
            if actual.datos_vuelo.id == vuelo.id:
                lista_vuelos.extraer_de_posicion(pos_actual)
                break
            actual = actual.siguiente
            pos_actual += 1
        db.delete(vuelo)
        db.commit()
        return {"acción": "rehecho", "tipo": "eliminar", "vuelo": vuelo.codigo}

    elif tipo == "insertar":
        vuelo, pos = accion[1], accion[2]
        db.add(vuelo)
        db.commit()
        lista_vuelos.insertar_en_posicion(vuelo, pos)
        return {"acción": "rehecho", "tipo": "insertar", "vuelo": vuelo.codigo}