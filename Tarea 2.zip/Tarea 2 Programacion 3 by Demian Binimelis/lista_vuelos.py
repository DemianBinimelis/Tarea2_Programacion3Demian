from nodo import Nodo

class ListaVuelos:
    def __init__(self):
        self.cabeza = None
        self.cola = None
        self._size = 0

    def insertar_al_frente(self, datos_vuelo):
        nuevo_nodo = Nodo(datos_vuelo)
        if not self.cabeza:
            self.cabeza = self.cola = nuevo_nodo
        else:
            if datos_vuelo.es_emergencia:
                nuevo_nodo.siguiente = self.cabeza
                self.cabeza.anterior = nuevo_nodo
                self.cabeza = nuevo_nodo
            else:
                actual = self.cabeza
                while actual.siguiente and actual.siguiente.datos_vuelo.es_emergencia:
                    actual = actual.siguiente
                nuevo_nodo.siguiente = actual.siguiente
                if actual.siguiente:
                    actual.siguiente.anterior = nuevo_nodo
                actual.siguiente = nuevo_nodo
                nuevo_nodo.anterior = actual
                if nuevo_nodo.siguiente is None:
                    self.cola = nuevo_nodo
        self._size += 1

    def insertar_al_final(self, datos_vuelo):
        nuevo_nodo = Nodo(datos_vuelo)
        if not self.cola:
            self.cabeza = self.cola = nuevo_nodo
        else:
            if datos_vuelo.es_emergencia:
                self.insertar_al_frente(datos_vuelo)
                return
            self.cola.siguiente = nuevo_nodo
            nuevo_nodo.anterior = self.cola
            self.cola = nuevo_nodo
        self._size += 1

    def insertar_en_posicion(self, datos_vuelo, lugar):
        if datos_vuelo.es_emergencia:
            self.insertar_al_frente(datos_vuelo)
            return

    def extraer_de_posicion(self, lugar):
        if not self._size:  
            return None
        if not (0 <= lugar < self._size):  
            return None
        if lugar == 0:
            datos_vuelo = self.cabeza.datos_vuelo
            self.cabeza = self.cabeza.siguiente
            if self.cabeza:
                self.cabeza.anterior = None
            else:
                self.cola = None
        elif lugar == self._size - 1:
            datos_vuelo = self.cola.datos_vuelo
            self.cola = self.cola.anterior
            if self.cola:
                self.cola.siguiente = None
            else:
                self.cabeza = None
        else:
            actual = self.cabeza
            for _ in range(lugar):
                actual = actual.siguiente
            datos_vuelo = actual.datos_vuelo
            actual.anterior.siguiente = actual.siguiente
            actual.siguiente.anterior = actual.anterior
        self._size -= 1
        return datos_vuelo

    def obtener_primero(self):
        return self.cabeza.datos_vuelo if self.cabeza else None

    def obtener_ultimo(self):
        return self.cola.datos_vuelo if self.cola else None

    def longitud(self):
        return self._size
    
    def reordenar_por_prioridad(self):
        if not self.cabeza or not self.cabeza.siguiente:
            return 

        vuelos = []
        actual = self.cabeza
        while actual:
            vuelos.append(actual.datos_vuelo)
            actual = actual.siguiente
        self.cabeza = self.cola = None
        self._size = 0

        for vuelo in sorted(vuelos, key=lambda x: not x.es_emergencia):
            self.insertar_al_final(vuelo)

lista_vuelos = ListaVuelos()