from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from vuelo_ORM import Base
import crud
from lista_vuelos import lista_vuelos

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Gestión Torre de Control")

def get_db():
    db = SessionLocal()
    try:
        crud.inicializar_lista(db)
        yield db
    finally:
        db.close()

@app.post("/vuelos/")
def crear_vuelo(datos: dict, db: Session = Depends(get_db), emergencia: bool = False):
    return crud.crear_vuelo(db, datos, emergencia)

@app.patch("/vuelos/reordenar")
def reordenar_vuelos(db: Session = Depends(get_db)):
    lista_vuelos.reordenar_por_prioridad()
    return {"mensaje": "Vuelos reordenados por prioridad"}

@app.get("/vuelos/")
def listar_vuelos():
    return crud.obtener_vuelos()

@app.delete("/vuelos/{posicion}")
def eliminar_vuelo(posicion: int, db: Session = Depends(get_db)):
    vuelo = crud.eliminar_vuelo(db, posicion)
    if not vuelo:
        raise HTTPException(status_code=404, detail="Vuelo no encontrado")
    return {"mensaje": "Vuelo eliminado", "vuelo": vuelo.codigo}

@app.post("/vuelos/insertar_en/{posicion}")
def insertar_en_posicion(datos: dict, posicion: int, db: Session = Depends(get_db)):
    return crud.insertar_en_posicion(db, datos, posicion)

@app.post("/undo/")
def deshacer(db: Session = Depends(get_db)):
    resultado = crud.undo(db)
    if not resultado:
        raise HTTPException(status_code=400, detail="Nada que deshacer")
    return resultado

@app.post("/redo/")
def rehacer(db: Session = Depends(get_db)):
    resultado = crud.redo(db)
    if not resultado:
        raise HTTPException(status_code=400, detail="Nada que rehacer")
    return resultado