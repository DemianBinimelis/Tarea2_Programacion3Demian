class Nodo:
    def __init__(self, datos_vuelo):
        self.datos_vuelo = datos_vuelo
        self.siguiente = None
        self.anterior = None


